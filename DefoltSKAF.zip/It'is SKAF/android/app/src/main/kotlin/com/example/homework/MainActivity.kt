package com.example.homework

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
