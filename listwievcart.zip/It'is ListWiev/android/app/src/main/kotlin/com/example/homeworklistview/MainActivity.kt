package com.example.homeworklistview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
