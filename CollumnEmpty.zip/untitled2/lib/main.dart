import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Empty Columns with ListView',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Они пустые, извините'),
        ),
        body: Row(
          children: <Widget>[
            Expanded(
              child: ListView.builder(
                itemCount: 15, // Количество пустых ячеек в первой колонке
                itemBuilder: (BuildContext ctx, int index) {
                  return ListTile(
                    title: Text('Пустота ${index + 1} Первая колонка'),
                  );
                },
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: 15, // Количество пустых ячеек во второй колонке
                itemBuilder: (BuildContext ctx, int index) {
                  return ListTile(
                    title: Text('Пустота ${index + 1} Вторая Колонка'),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
